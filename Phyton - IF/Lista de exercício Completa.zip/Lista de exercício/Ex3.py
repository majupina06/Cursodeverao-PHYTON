n1 = int(input("Digite um número: "))

if n1 % 2 == 0:
    print(f"O número é par")
else:
    print(f"O número é ímpar")

