n1 = float(input("Digite um número: "))
n2 = float(input("Digite outro número: "))
n3 = float(input("Digite mais um número: "))

if n1 > n2 and n1 > n3:
    print(f"Condição satisfeita")
else:
    print(f"Erro")

